/**==================================================================*
* Appliication Name: ZUI5_FC_UPDATE                                  *
* Description:      Application to Create ZFDC Quotations from ZFDU, *
*                   Change the exiting ZFDC Quotations and create    *
*                   ZFDC Quotation by copying Existing Quotation.    *
*Controller:        COntroller to display Quotations Overview        *
* Defect# :         16472                                            *
* Change FDD/TDD:   FUL_EXT-072_NEW                                  *
* Transport Number: RD2K906449                                       *
* Developer:        Teja Konapalli                                   *
* Creation Date:    APR-11-2023                                      *
*=================================================================== */
sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/m/MessageBox",
    "sap/ui/model/Sorter",
    "sap/m/Token",
    "sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, formatter, Filter, MessageBox, Sorter, Token, FilterOperator) {
    "use strict";
    var prevSldTo, matIpId, sldToIpId,loginSldToPartner;
    var oEntMtModel = new JSONModel();
    var oProgModel = new JSONModel();
    var oUserModel = new JSONModel();
    var oSldToModel = new JSONModel();
    return BaseController.extend("sacquotfc.controller.Worklist", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

        /**
         * Called when the worklist controller is instantiated.
         * @public
         */
        onInit: function () {
            var oViewModel;

            // keeps the search state
            this._aTableSearchState = [];
            // Model used to manipulate control states
            oViewModel = new JSONModel({
                worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
                shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
                shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
                tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
                
            });
            this.setModel(oViewModel, "worklistView");

        // Retrive Value Help data initially
            var oComponent = this.getOwnerComponent();
            var oDataModel = oComponent.getModel();
        //    var oSldToModel = new sap.ui.model.json.JSONModel();
          //  var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURI, true);
            //var oDataModel = this.getView().getModel();
          //  var oCbox = this.getView().byId("ipSoldTo");
            var sldEntityset = "/SoldtoHelpSet";
            var entEntityset = "/EntlHelpSet";
            var programset = "/ProgramHelpSet";
            var userDetailset = "/UserDetailsSet('DUMMYUSER')";
            oDataModel.read(sldEntityset, {
                success: function (oData, response) {
                    oSldToModel.setData(oData);
                 //   oCbox.setModel(oSldToModel, "soldToModel");
                // this.getOwnerComponent.setModel(oSldToModel,"soldToModel");
              //      sap.ui.getCore().setModel(oSldToModel, "gSldToModel");
                }
            })
        // retrive Entitlement type(Progam type) model  
            oDataModel.read(entEntityset, {
                success: function (oData, response) {
                    oEntMtModel.setData(oData);
                //    sap.ui.getCore().setModel(oEntMtModel, "gEntModel");
                 //      oCbox.setModel(oSldToModel, "entToModel");
                }
            })
        // retrive Entitlement (Progam ) model
            oDataModel.read(programset, {
                success: function (oData, response) {
                    oProgModel.setData(oData);
                 //   sap.ui.getCore().setModel(oProgModel, "gProgModel");
                }
            })
        // retrive User Details (LOgin User) model
            oDataModel.read(userDetailset, {
                success: function (oData, response) {
                    oUserModel.setData(oData);
                      loginSldToPartner = oData.Partner;
                      this.setModel(oUserModel,"userModel")

                }
            }) 
        },
        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

        /**
         * Triggered by the table's 'updateFinished' event: after new table
         * data is available, this handler method updates the table counter.
         * This should only happen if the update was successful, which is
         * why this handler is attached to 'updateFinished' and not to the
         * table's list binding's 'dataReceived' method.
         * @param {sap.ui.base.Event} oEvent the update finished event
         * @public
         */
        onUpdateFinished: function (oEvent) {
            // update the worklist's object counter after the table update
            var sTitle,
                oTable = oEvent.getSource(),
                iTotalItems = oEvent.getParameter("total");
            // only update the counter if the length is final and
            // the table is not empty
            if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
                sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
            } else {
                sTitle = this.getResourceBundle().getText("worklistTableTitle");
            }
            this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
        },

        /**
         * Event handler when a table item gets pressed
         * @param {sap.ui.base.Event} oEvent the table selectionChange event
         * @public
         */

        /**
         * Event handler for navigating back.
         * Navigate back in the browser history
         * @public
         */
        onNavBack: function () {
            // eslint-disable-next-line sap-no-history-manipulation
            history.go(-1);
        },


        onSearch: function (oEvent) {
            if (oEvent.getParameters().refreshButtonPressed) {
                // Search field's 'refresh' button has been pressed.
                // This is visible if you select any main list item.
                // In this case no new search is triggered, we only
                // refresh the list binding.
                this.onRefresh();
            } else {
                var aTableSearchState = [];
                var sQuery = oEvent.getParameter("query");

                if (sQuery && sQuery.length > 0) {
                    aTableSearchState = [new Filter("Program", FilterOperator.Contains, sQuery)];
                }
                this._applySearch(aTableSearchState);
            }

        },
        /*==============================================================*/
        /*Search Help Methods                                           */
        /*==============================================================*/
        //****Retrive Material list to show up in Value Help.
        onMatHelpRequest: function (oEvent) {
            matIpId = oEvent.getSource().getId();
            this._getmatf4Dialog().open(oEvent);
        },
        /*    onMatHelpRequest: function () {
                this._getmatf4Dialog().open();
            },*/
        _getmatf4Dialog: function (oEvent) {
            if (!this._oDialog) {
                this._oDialog = sap.ui.xmlfragment("idFragmentMatF4", "sacquotfc.view.fragments.Matf4", this);
                this.getView().addDependent(this._oDialog);
               // var oTable = sap.ui.getCore().byId("idFragmentMatF4--matSrch");
                var oTable = sap.ui.core.Fragment.byId("idFragmentMatF4", "matSrch");
                var oDataModel = this.getView().getModel();
                var oModel = new sap.ui.model.json.JSONModel();
                var entityset = "/MaterialHelpSet";
                oDataModel.read(entityset, {
                    success: function (oData, response) {
                        oModel.setData(oData);
                        oTable.setModel(oModel, "matsModel");
                        var data = oData.results;
                    data.forEach(function (item) {
                        item.matFull = item.Material + item.MatlDesc;
                    });
                    },
                    error: function (error) {
                    }
                });
            }
            return this._oDialog;
        },
        onMatf4Close: function (oEvent) {
            //  var matnrIp = this.byId("ipMatnr");
            var matnrIp = sap.ui.getCore().byId(matIpId);
            var copmatnr = sap.ui.core.Fragment.byId("idFragment" , "idMatnr");
          if(copmatnr){
            var copmatnrid = copmatnr.getId();
          } 
            //   var maktxIp = this.byId("matText");
            var oItem = oEvent.getSource();
            var oBindingContext = oItem.getBindingContext("matsModel");
            var aContexts = oEvent.getParameter("selectedContexts");
            var val, maktx;
            if (oBindingContext) {
                //	oBindingContext.map(function(oBindingContext) {
                val = oBindingContext.getObject().Material;
                maktx = oBindingContext.getObject().MatlDesc;
                if (matIpId === copmatnrid ) {
                    matnrIp.setValue(val);
                    var matDescIp = sap.ui.core.Fragment.byId("idFragment","matDesc");
                    matDescIp.setValue(maktx);
                } else {
                    matnrIp.setValue(val + '-' + maktx);
                }
                matnrIp.setValueState(sap.ui.core.ValueState.None); // remove error state 
            }
            if (!val) {
                matnrIp.setValue(null);
                matnrIp.setValueState(sap.ui.core.ValueState.Error); // Make the field into Error state
                matnrIp.setValueStateText("Material is mandatory");
            }
            this._getmatf4Dialog().close()
        },
        //Material Live Search in F4 healp.
        onMatF4LiveSearch: function (oEvent) {
            // build filter array
            var aFilters = [];
            var id = oEvent.getSource().getId();
            var sQuery = sap.ui.getCore().byId(id).getValue();
            if (sQuery) {
                //  var afilter1 = new sap.ui.model.Filter("Matnr", FilterOperator.Contains, sQuery);
                var afilter2 = new sap.ui.model.Filter("matFull", FilterOperator.Contains, sQuery);
                //     aFilters.push(afilter1);
                aFilters.push(afilter2);
            }
            // filter binding
            var oList = sap.ui.core.Fragment.byId("idFragmentMatF4","matSrch");
            var oBinding = oList.getBinding("items");

            oBinding.filter(aFilters, "Application");
            oBinding.refresh();
        },
        //****Retrive SHip To list to show up in Value Help in POPUP.
        onShpToHelpRequest: function () {
            this._getShpTof4Dialog().open();
        },
        //OPen Search Help Dialog.
        _getShpTof4Dialog: function () {
            if (!this._shpF4Dialog) {
                this._shpF4Dialog = sap.ui.xmlfragment("idFragmentShpToF4", "sacquotfc.view.fragments.Shiptof4", this);
                this.getView().addDependent(this._shpF4Dialog);
            }
                var oTable = sap.ui.core.Fragment.byId("idFragmentShpToF4" , "shpToSrch");
                var sldToFilter = new sap.ui.model.Filter("Partner", FilterOperator.EQ, loginSldToPartner);
                var oFilter = [];
                oFilter.push(sldToFilter);
                var oDataModel = this.getView().getModel();
                var oModel = new sap.ui.model.json.JSONModel();
                var entityset = "/ShiptoHelpSet";
                oDataModel.read(entityset, {
                    filters: oFilter,
                    success: function (oData, response) {
                        oModel.setData(oData);
                        oTable.setModel(oModel, "shpTosModel");
                        var data = oData.results;
                        data.forEach(function (item) {
                            item.shpToFull = item.Partner + item.PartnerName;
                        });
                    },
                    error: function (error) {
                    }
                });
         //   }
            return this._shpF4Dialog;
        },
        onShpTof4Close: function (oEvent) {
            var shipToIp = sap.ui.core.Fragment.byId("idFragment","idshipTo");
            var shipTonamIp = sap.ui.core.Fragment.byId("idFragment","shpName");
            var oItem = oEvent.getSource();
            var oBindingContext = oItem.getBindingContext("shpTosModel");
            var aContexts = oEvent.getParameter("selectedContexts");
            var shipTo, shipToNam;
            if (oBindingContext) {
                shipTo = oBindingContext.getObject().Partner;
                shipToNam = oBindingContext.getObject().PartnerName;
                // shipToIp.setValue(shipTo + '-' + shipToNam);
                shipToIp.setValue(shipTo);
                shipTonamIp.setValue(shipToNam);
                shipToIp.setValueState(sap.ui.core.ValueState.None); // remove error state 
            }
            if (!shipTo) {
                shipToIp.setValue(null);
                shipToIp.setValueState(sap.ui.core.ValueState.Error); // Make the field into Error state
                shipToIp.setValueStateText("Ship To is mandatory");
            }
            this._getShpTof4Dialog().close()
           // this._getShpTof4Dialog().destroy(true);
            //  delete this._getShpTof4Dialog();
        },
        // Live search on ship to value Help Dialog
        onShpToF4LiveSearch: function (oEvent) {
            // build filter array
            var aFilters = [];
            var id = oEvent.getSource().getId();
            var sQuery = sap.ui.getCore().byId(id).getValue();
            if (sQuery) {
                //  var afilter1 = new sap.ui.model.Filter("Matnr", FilterOperator.Contains, sQuery);
                var afilter2 = new sap.ui.model.Filter("shpToFull", FilterOperator.Contains, sQuery);
                //     aFilters.push(afilter1);
                aFilters.push(afilter2);
            }
            // filter binding
            var oList = sap.ui.core.Fragment.byId("idFragmentShpToF4" , "shpToSrch");
            var oBinding = oList.getBinding("items");

            oBinding.filter(aFilters, "Application");
            oBinding.refresh();
        },
    // Retrive sold Tos into Vlaue Help Screen.    
        onSoldToF4HelpSC: function (oEvent) {
            this._getSoldTof4Dialog(oEvent).open();
        },
        _getSoldTof4Dialog: function (oEvent) {
            if (!this._soldToF4Dialog) {
                this._soldToF4Dialog = sap.ui.xmlfragment("idFragmentsoldToF4", "sacquotfc.view.fragments.Soldtof4", this);
                this.getView().addDependent(this._soldToF4Dialog);
            }
            if (oEvent) {
                sldToIpId = oEvent.getSource().getId();
            }
          //  var soldToModel = sap.ui.getCore().getModel("gSldToModel");
            var oTable = sap.ui.core.Fragment.byId("idFragmentsoldToF4","soldTOSrch");
            var copySldTo = sap.ui.core.Fragment.byId("idFragment","idSoldTo");
            if (copySldTo){
              var copySldToid =   copySldTo.getId();
            }
            if (sldToIpId === copySldToid) {
                oTable.setMode("SingleSelectLeft");
            } else {
                oTable.setMode("MultiSelect");
            }
            oTable.setModel(oSldToModel, "soldToModel");
            this._f4searchDialog();
            return this._soldToF4Dialog;
        },
        onSoldTof4Select: function (evt) {
            var oTable = sap.ui.core.Fragment.byId("idFragmentsoldToF4","soldTOSrch");
            var fltIP = sap.ui.core.Fragment.byId("idFragF4search","fltIP");
            fltIP.setValue("");
            var oItems = oTable.getBinding("items");
            var aItems = oTable.getItems();            
            if (sldToIpId === "idFragment--idSoldTo") {
                for (var i = 0; i < aItems.length; i++) {
                    if (aItems[i].getSelected() === true) {
                        var selbindctx = aItems[i].getBindingContext("soldToModel");
                        var SoldTo = selbindctx.getProperty("Partner");
                        var sTDesc = selbindctx.getProperty("PartnerName");
                        sap.ui.core.Fragment.byId("idFragment","sldName").setValue(sTDesc);
                        sap.ui.getCore().byId(sldToIpId).setValue(SoldTo);
                        break;
                    }
                }
            } else {
               var oMultiInput = this.byId("ipSoldTo");
                oMultiInput.removeAllTokens();
                for (var i = 0; i < aItems.length; i++) {
                    if (aItems[i].getSelected() === true) {
                        oMultiInput.addToken(new Token({
                            text: aItems[i].getBindingContext("soldToModel").getProperty("Partner")
                        }));
                    }
                }
            }
          //  this._getSoldTof4Dialog().close();
          oItems.filter([]);//REset filter before selecting the list
          this.onSoldTof4Close();
        },
        onSoldTof4Close: function () {
            this._getSoldTof4Dialog().close();
            var soldTo = this.byId("ipSoldTo").getTokens();
            if (soldTo.length === 0) {
                this.byId("ipSoldTo").setValueState(sap.ui.core.ValueState.Error); // Add error state
                this.byId("ipSoldTo").setValueStateText("Sold To is mandatory"); 
            } else {
                this.byId("ipSoldTo").setValueState(sap.ui.core.ValueState.None); // remove error state 
            }
        },
        // Build search/FIlter Dailog in SOld to F4 Help
        _f4searchDialog: function () {
            if (!this._oResponsivePopover) {
                this._oResponsivePopover = sap.ui.xmlfragment("idFragF4search", "sacquotfc.view.fragments.F4search", this);
                this._oResponsivePopover.setModel(this.getView().getModel());

                var oTable = sap.ui.core.Fragment.byId("idFragmentsoldToF4","soldTOSrch");
                var that = this;
                oTable.addEventDelegate({
                    onAfterRendering: function () {
                        var oHeader = this.$().find('.sapMListTblHeaderCell'); //Get hold of table header elements
                        for (var i = 0; i < oHeader.length; i++) {
                            var oID = oHeader[i].id;
                            that.onClick(oID);
                        }
                    }
                }, oTable);
            }
        },
        //Add Event to the Headers to show soldto Search popup
        onClick: function (oID) {
            var that = this;
            $('#' + oID).click(function (oEvent) { //Attach Table Header Element Event
                var oTarget = oEvent.currentTarget; //Get hold of Header Element
                var oLabelText = oTarget.childNodes[0].textContent; //Get Column Header text
                var oIndex = oTarget.id.slice(-1); //Get the column Index
                var oView = that.getView();
                var oTable = sap.ui.core.Fragment.byId("idFragmentsoldToF4","soldTOSrch");
                var oModel = oTable.getModel("soldToModel").getProperty('/results');
                oIndex++;
                var key;
                switch (oIndex) {
                    case 1:
                        key = "Partner";
                        break;
                    case 2:
                        key = "PartnerName";
                        break;
                    case 3:
                        key = "SearchTerm1";
                        break;
                    case 4:
                        key = "SearchTerm2";
                        break;
                    case 5:
                        key = "City";
                        break;
                    case 6:
                        key = "State";
                        break;
                }
                //Clear the Filter value if any before opening the search popup 
                var fltIP = sap.ui.core.Fragment.byId("idFragF4search","fltIP");
                fltIP.setValue("");
                //  var oKeys = Object.keys(oModel[0]); //Get Hold of Model Keys to filter the value
                //   var view = oView.getModel();
                oView.getModel("worklistView").setProperty("/bindingValue", key); //Save the key value to property
                that._oResponsivePopover.openBy(oTarget);
            });
        },
        onOpen: function (oEvent) {
            //On Popover open focus on Input control
            var oPopover = sap.ui.getCore().byId(oEvent.getParameter("id"));
            var oPopoverContent = oPopover.getContent()[0];
            var oCustomListItem = oPopoverContent.getItems()[2];
            var oCustomContent = oCustomListItem.getContent()[0];
            var oInput = oCustomContent.getItems()[1];
            oInput.focus();
          //  oInput.$().find('.sapMInputBaseInner')[0].select();
        },
        //Live searh the F4 help data.
        onF4LiveSearch: function (oEvent) {
            var oValue = oEvent.getParameter("value");
            var oMultipleValues = oValue.split(",");
            var oTable = sap.ui.core.Fragment.byId("idFragmentsoldToF4","soldTOSrch");
            var oBindingPath = this.getView().getModel("worklistView").getProperty("/bindingValue"); //Get Hold of Model Key value that was saved
            var aFilters = [];
            for (var i = 0; i < oMultipleValues.length; i++) {
                var oFilter = new sap.ui.model.Filter(oBindingPath, FilterOperator.Contains, oMultipleValues[i]);
                aFilters.push(oFilter)
            }
            var oItems = oTable.getBinding("items");
            oItems.filter(aFilters, "Application");
            //  oItems.refesh();
            //  this._oResponsivePopover.close();
        },
        onAscending: function () {
            var oTable = sap.ui.core.Fragment.byId("idFragmentsoldToF4","soldTOSrch");
            var oItems = oTable.getBinding("items");
            //   var omodel = oTable.getModel("matsModel");
            // var oBindingPath = omodel.getProperty("/");
            var oBindingPath = this.getView().getModel("worklistView").getProperty("/bindingValue");
            var oSorter = new Sorter(oBindingPath);
            oItems.sort(oSorter);
        },

        onDescending: function () {
            var oTable = sap.ui.core.Fragment.byId("idFragmentsoldToF4","soldTOSrch");
            var oItems = oTable.getBinding("items");
            var oBindingPath = this.getView().getModel("worklistView").getProperty("/bindingValue");
            var oSorter = new Sorter(oBindingPath, true);
            oItems.sort(oSorter);
            
        },
        onF4SearchClose: function(){
            this._oResponsivePopover.close();
            var fltIP = sap.ui.core.Fragment.byId("idFragF4search","fltIP");
            fltIP.setValue("");
        },
        /*============================================================= */
        /* Methods for Selection screen validations  and Copy pop Up    */
        /*============================================================= */
       //Program Year
        onYearChange: function (oEvent) {
            var fisYear = this.byId("programYearcbx").getSelectedKey();
            if (!fisYear) {
                this.byId("programYearcbx").setValueState(sap.ui.core.ValueState.Error);
                this.byId("programYearcbx").setValueStateText("Select a valid year from drop down list");
            } else {
                this.byId("programYearcbx").setValueState(sap.ui.core.ValueState.None);
            }
        },
        //Validate Program (Entitlement)
        onProgramChange: function () {
            var Program = this.byId("programcbx").getSelectedKey();
            if (!Program) {
                this.byId("programcbx").setValueState(sap.ui.core.ValueState.Error);
                this.byId("programcbx").setValueStateText("Select a valid Program from drop down list");
            } else {
                this.byId("programcbx").setValueState(sap.ui.core.ValueState.None);
            }
        },
        //Validate Entitlement type(Copy pop UP)
        onEntitleChange: function () {
            var EntMent = sap.ui.core.Fragment.byId("idFragment","idEType").getSelectedKey();
            if (!EntMent) {
                ssap.ui.core.Fragment.byId("idFragment","idEType").setValueState(sap.ui.core.ValueState.Error);
                sap.ui.core.Fragment.byId("idFragment","idEType").setValueStateText("Select a valid Entitlement Type from drop down list");
            } else {
                sap.ui.core.Fragment.byId("idFragment","idEType").setValueState(sap.ui.core.ValueState.None);
            }
        },
        /*============================================================= */
        /* Methods for Data Retrival                                    */
        /*============================================================= */
        //retrive Quotatoins based and selection screen.
        getQuotes: function (oEvent) {
            var matnrtxt = this.byId("ipMatnr").getValue();
            var soldTo = this.byId("ipSoldTo").getTokens();
            var zzProgram = this.byId("programcbx").getSelectedKey();
            var fisYear = this.byId("programYearcbx").getSelectedKey();
            var oFilters = [];
            var dataModel = [];
           //Validate the Selection Screen.
            if (soldTo.length !== 0) {
                this.byId("ipSoldTo").setValueState(sap.ui.core.ValueState.None); // remove error state 
                for (var i = 0; i < soldTo.length; i++) {
                    var oFiltersl = new sap.ui.model.Filter("SoldTo", sap.ui.model.FilterOperator.EQ, soldTo[i].getText());
                    oFilters.push(oFiltersl);
                }

            }
            else {
                this.byId("ipSoldTo").setValueState(sap.ui.core.ValueState.Error);
                this.byId("ipSoldTo").setValueStateText("Sold To is mandatory");
                return;
            };
            if (matnrtxt) {
                var matnr = matnrtxt.split('-')
                var oFilterMt = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, matnr[0]);
                oFilters.push(oFilterMt);
            }
            else {
                this.byId("ipMatnr").setValueState(sap.ui.core.ValueState.Error);  // if the field is empty after change, it will go red
                this.byId("ipMatnr").setValueStateText("Material is mandatory");
                return;
            };
            if (zzProgram) {
                var oFilterpg = new sap.ui.model.Filter("Program", sap.ui.model.FilterOperator.EQ, zzProgram);
                this.byId("programcbx").setValueState(sap.ui.core.ValueState.None);
                oFilters.push(oFilterpg);
            }else{
                this.byId("programcbx").setValueState(sap.ui.core.ValueState.Error);
                this.byId("programcbx").setValueStateText("Program is Mandatory");
                return;
            };
            if (fisYear) {
                this.byId("programYearcbx").setValueState(sap.ui.core.ValueState.None);
                var oFilterfy = new sap.ui.model.Filter("Year", sap.ui.model.FilterOperator.EQ, fisYear);
                oFilters.push(oFilterfy);
            } else {
                this.byId("programYearcbx").setValueState(sap.ui.core.ValueState.Error);
                this.byId("programYearcbx").setValueStateText("Program Year is Mandatory");
                return;
            };
            var oTable = this.getView().byId("table");
            var oDataModel = this.getView().getModel();
            var oModel = new sap.ui.model.json.JSONModel();
            var entityset = "/QuotationsSet";
            oTable.setBusy(true);
            //Retrive the Quotations
            oDataModel.read(entityset, {
                filters: oFilters,
                success: function (oData, response) {
                    var data = oData.results;
                    data.forEach(function (item) {
                        item.shipToDesc = item.ShipTo + item.ShipToName;
                        item.SoldToDesc = item.SoldTo + item.SoldToName;
                        dataModel.push(item);
                    });
                    oModel.setData(oData);
                    oTable.setModel(oModel, "quotesModel");
                    sap.ui.getCore().setModel(oModel, "gquotesModel");
                    oTable.setBusy(false);
                },
                error: function (error) {
                    oTable.setBusy(false);
                    oTable.setModel(oModel,"quotesModel");
                    var errorObj1 = JSON.parse(error.responseText);
                    sap.m.MessageBox.show(
                        errorObj1.error.message.value,
                        sap.m.MessageBox.Icon.ERROR,
                        "Data Error"
                    );
                }
            });
        },
    /*=============================================================*/
    /* Methods to Search  Forecats Overview Table                  */
    /*=============================================================*/
        onShpToSearch: function (oEvent) {
            var aFilters = [];
            var id = oEvent.getSource().getId();
            var sQuery = sap.ui.getCore().byId(id).getValue();
            var sldVal = this.getView().byId("searchSldTo").getValue();
            if (sQuery) {
                if (sldVal) {
                    var afilter1 = new sap.ui.model.Filter("SoldToDesc", FilterOperator.Contains, sldVal);
                    aFilters.push(afilter1);
                }
                var afilter2 = new sap.ui.model.Filter("shipToDesc", FilterOperator.Contains, sQuery);
                aFilters.push(afilter2);
            }
            // filter binding
            var oList = this.getView().byId("table");
            var oBinding = oList.getBinding("items");
            oBinding.filter(aFilters, "Application");
            oBinding.refresh();

        },
        onSldToSearch: function (oEvent) {
            var aFilters = [];
            var id = oEvent.getSource().getId();
            var sQuery = sap.ui.getCore().byId(id).getValue();
            var shpVal = this.getView().byId("searchField").getValue();
            if (sQuery) {
                if (shpVal) {
                    var afilter1 = new sap.ui.model.Filter("shipToDesc", FilterOperator.Contains, shpVal);
                    aFilters.push(afilter1);
                }
                var afilter2 = new sap.ui.model.Filter("SoldToDesc", FilterOperator.Contains, sQuery);
                aFilters.push(afilter2);
            }
            // filter binding
            var oList = this.getView().byId("table");
            var oBinding = oList.getBinding("items");
            oBinding.filter(aFilters, "Application");
            oBinding.refresh();
        },
    /*=============================================================*/
    /* Methods for COpy Functionality*/
    /*=============================================================*/
        onCopy: function (oEvent) {
            var oTable = this.byId("table");
            var selectedItems = oTable.getSelectedItem();
            //   var itemIndex = oTable.indexOfItem(selectedItems);
            if (selectedItems) {
                var selbindctx = selectedItems.getBindingContext("quotesModel");
                var Matnr = selbindctx.getProperty("Material");
                var SoldTo = selbindctx.getProperty("SoldTo");
                var ShipTo = selbindctx.getProperty("ShipTo");
                var Zzprogram = selbindctx.getProperty("Program");
                var EntType = selbindctx.getProperty("EntType");
                var FisYear = selbindctx.getProperty("Year");
                var sTDesc = selbindctx.getProperty("SoldToName");
                var shTDesc = selbindctx.getProperty("ShipToName");
                var mTDesc = selbindctx.getProperty("MatlDesc");

                // oEntlment.setModel(oEntMtModel,"entModel");
                this._getDialog();

                //get the reference of input fields of fragment and set the values
                sap.ui.core.Fragment.byId("idFragment","idMatnr").setValue(Matnr);
                sap.ui.core.Fragment.byId("idFragment","idSoldTo").setValue(SoldTo);
                sap.ui.core.Fragment.byId("idFragment","shipToHide").setValue(ShipTo);
                sap.ui.core.Fragment.byId("idFragment","idProgram").setSelectedKey(Zzprogram);
                sap.ui.core.Fragment.byId("idFragment","idYear").setValue(FisYear);
                sap.ui.core.Fragment.byId("idFragment","idshipTo").setValue(ShipTo);
                sap.ui.core.Fragment.byId("idFragment","EntHide").setValue(EntType);
                sap.ui.core.Fragment.byId("idFragment","idEType").setModel(oEntMtModel, "entModel");
                sap.ui.core.Fragment.byId("idFragment","idProgram").setModel(oProgModel, "prgModel");
                sap.ui.core.Fragment.byId("idFragment","idEType").setSelectedKey(EntType);
                sap.ui.core.Fragment.byId("idFragment","sldName").setValue(sTDesc);
                sap.ui.core.Fragment.byId("idFragment","shpName").setValue(shTDesc);
                sap.ui.core.Fragment.byId("idFragment","matDesc").setValue(mTDesc);
            } else {
              //  MessageBox.error("Please Select a Quotation to Copy");
                sap.m.MessageBox.show(
                    "Please Select a Quotation to Copy",
                    sap.m.MessageBox.Icon.ERROR,
                    "Input Error"
                );
            }
        },
        _getDialog: function () {
            // create a fragment with dialog, and pass the selected data
            if (!this.oCopyDialog) {
                // This fragment can be instantiated from a controller as follows:
                //this.dialog = sap.ui.xmlfragment("idFragment", "sacquotfc.view.fragments.Copypopup", this);
                this.oCopyDialog = sap.ui.xmlfragment("idFragment", "sacquotfc.view.fragments.Copypopup", this);
               // this.getView().addDependent(this.oCopyDialog);
               this.getView().addDependent(this.oCopyDialog);
               this.oCopyDialog.setModel(this.getView().getModel());
            }
            //debugger;
           // return this.dialog;
           this.oCopyDialog.open();
        },
        closeDialog: function () {
            this.oCopyDialog.close()
          //  this._getDialog().destroyContent();

        },
        onSave: function () {
            //copy the selected to make use in the next view
            var oTable = this.getView().byId("table");
            var selectedItems = oTable.getSelectedItem();
            var oCopyrec = new sap.ui.model.json.JSONModel();
            if (selectedItems) {
                var selbindctx = selectedItems.getBindingContext("quotesModel");
                oCopyrec.setProperty("/", {
                    "ShiptTo": selbindctx.getProperty("ShipTo"),
                    "SoldTo": selbindctx.getProperty("SoldTo"),
                    "Material": selbindctx.getProperty("Material"),
                    "Program": selbindctx.getProperty("Program"),
                    "Year": selbindctx.getProperty("Year"),
                    "EntType": selbindctx.getProperty("EntType")
                });
                sap.ui.getCore().setModel(oCopyrec, "gCpyRecMdl");
            };
            var oDescModel = new sap.ui.model.json.JSONModel()
            var matnr = sap.ui.core.Fragment.byId("idFragment","idMatnr").getValue(),
                soldTo = sap.ui.core.Fragment.byId("idFragment","idSoldTo").getValue(),
                shipTo = sap.ui.core.Fragment.byId("idFragment","idshipTo").getValue(),
                program = sap.ui.core.Fragment.byId("idFragment","idProgram").getSelectedKey(),
                year = sap.ui.core.Fragment.byId("idFragment","idYear").getValue(),
                entType = sap.ui.core.Fragment.byId("idFragment","idEType").getSelectedKey(),
                sldName = sap.ui.core.Fragment.byId("idFragment","sldName").getValue(),
                matName = sap.ui.core.Fragment.byId("idFragment","matDesc").getValue(),
                shpName = sap.ui.core.Fragment.byId("idFragment","shpName").getValue();
            if (!shipTo) {
                sap.ui.core.Fragment.byId("idFragment","idshipTo").setValueState(sap.ui.core.ValueState.Error);
                sap.ui.core.Fragment.byId("idFragment","idshipTo").setValueStateText("Ship To is Mandatory");
                return;
            } else {
                sap.ui.core.Fragment.byId("idFragment","idshipTo").setValueState(sap.ui.core.ValueState.None);
            }
            if (!entType) {
                sap.ui.core.Fragment.byId("idFragment","idEType").setValueState(sap.ui.core.ValueState.Error);
                sap.ui.core.Fragment.byId("idFragment","idEType").setValueStateText("Select a Valid Program type from Drop down");
                return;
            } else {
                sap.ui.core.Fragment.byId("idFragment","idEType").setValueState(sap.ui.core.ValueState.None);

            }
            //  fromShpTo = sap.ui.getCore().byId("idFragment--shpName").getValue();
            // prepare descriptions model
            oDescModel.setProperty("/", {
                "SoldToName": sldName,
                "ShipToName": shpName,
                "MatlDesc": matName
            });
            //prepare filters to check if record exist with SHip To
            var oModel = this.getView().getModel();
            var params = "(SoldTo='" + soldTo + "',ShipTo='" + shipTo + "',Material='" + matnr + "',Year='" + year
                + "',Program='" + program + "',EntType='" + entType + "')"
            //  params.replace(/\s/g, '');
            var url = "/QuotationsSet" + params;
            sap.ui.core.BusyIndicator.show()
            oModel.read(url, {
                async: false,
                success: function (oData, sResponse) {
                    //    function(success) {
                    sap.ui.core.BusyIndicator.hide();
                    sap.ui.getCore().setModel(oDescModel, "gDescModel");
                    this.navToDtl();
                }.bind(this),
                error: function (Error) {
                    sap.ui.core.BusyIndicator.hide();
                    //  var errorObj1 = JSON.parse(Error.response.body);
                    var errorObj1 = JSON.parse(Error.responseText);
                    sap.m.MessageBox.show(
                        errorObj1.error.message.value,
                        sap.m.MessageBox.Icon.ERROR,
                        "Update Error"
                    );
                }
            });
            sap.ui.core.BusyIndicator.hide();
            this._getDialog().close();

        },
        navToDtl: function () {
            var matnr = sap.ui.core.Fragment.byId("idFragment","idMatnr").getValue(),
                soldTo = sap.ui.core.Fragment.byId("idFragment","idSoldTo").getValue(),
                shipTo = sap.ui.core.Fragment.byId("idFragment","idshipTo").getValue(),
                program = sap.ui.core.Fragment.byId("idFragment","idProgram").getSelectedKey(),
                year = sap.ui.core.Fragment.byId("idFragment","idYear").getValue(),
                entType = sap.ui.core.Fragment.byId("idFragment","idEType").getSelectedKey()
              //  fromShpTo = sap.ui.getCore().byId("idFragment--shipToHide").getValue(),
              //  fromEnt = sap.ui.getCore().byId("idFragment--EntHide").getValue();
            var oTable = this.byId("table");
            var selectedItems = oTable.getSelectedItem();
            var itemIndex = oTable.indexOfItem(selectedItems);
            this.getRouter().navTo("object",
                {
                    matnr: matnr,
                    soldTo: soldTo,
                    shipTo: shipTo,
                    year: year,
                    program: program,
                    entType: entType,
                    cidx: itemIndex
                });
        },
        dialogAfterClose: function(oEvent){
          //  var dialog = oEvent.getSource().getId();
          //  dialog.destroy();//destroy only the content inside the Dialog
          this.oCopyDialog.destroy();//destroy only the content inside the Dialog
          this.oCopyDialog = undefined;
        },
        /**
         * Event handler for refresh event. Keeps filter, sort
         * and group settings and refreshes the list binding.
         * @public
         */
        onRefresh: function () {
            var oTable = this.byId("table");
            oTable.getBinding("items").refresh();
        },

        /* ============================================================*/
        /* Navigation Method                                           */
        /* ============================================================*/

        /**
         * Shows the selected item on the object page
         * @param {sap.m.ObjectListItem} oItem selected Item
         * @private
         */
        onPress: function (oEvent) {
            // The source is the list item that got pressed
            this._showObject(oEvent.getSource());
        },
        _showObject: function (oItem) {
            //   var oHeadModel = new sap.ui.model.json.JSONModel()
            var matnr = oItem.getBindingContext('quotesModel').getProperty('Material'),
                shipTo = oItem.getBindingContext('quotesModel').getProperty('ShipTo'),
                soldTo = oItem.getBindingContext('quotesModel').getProperty('SoldTo'),
                year = oItem.getBindingContext('quotesModel').getProperty('Year'),
                entType = oItem.getBindingContext('quotesModel').getProperty('EntType'),
                program = oItem.getBindingContext('quotesModel').getProperty('Program');
            var oDescModel = new sap.ui.model.json.JSONModel();
            oDescModel.setProperty("/", {
                "SoldToName": oItem.getBindingContext('quotesModel').getProperty('SoldToName'),
                "ShipToName": oItem.getBindingContext('quotesModel').getProperty('ShipToName'),
                "MatlDesc": oItem.getBindingContext('quotesModel').getProperty('MatlDesc')
            });
            sap.ui.getCore().setModel(oDescModel, "gDescModel");
            this.getRouter().navTo("object",
                {
                    matnr: matnr,
                    soldTo: soldTo,
                    shipTo: shipTo,
                    year: year,
                    program: program,
                    entType: entType,
                    cidx: " "
                });
        },
        updateFinished: function () {
            var oViewModel,
                iOriginalBusyDelay,
                oTable = this.byId("table")
            iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
            // Restore original busy indicator delay for worklist's table
            oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
            oTable.setBusy(false);
        },

        /**
         * Internal helper method to apply both filter and search state together on the list binding
         * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
         * @private
         */
        _applySearch: function (aTableSearchState) {
            var oTable = this.byId("table"),
                oViewModel = this.getModel("worklistView");
            oTable.getBinding("items").filter(aTableSearchState, "Application");
            // changes the noDataText of the list in case there are no filter results
            if (aTableSearchState.length !== 0) {
                oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
            }
        },
    })

});
