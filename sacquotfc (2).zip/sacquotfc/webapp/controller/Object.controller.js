/*===================================================================*
* Appliication Name: ZUI5_FC_UPDATE                                  *
* Description:      Application to Create ZFDC Quotations from ZFDU, *
*                   Change the exiting ZFDC Quotations and create    *
*                   ZFDC Quotation by copying Existing Quotation.    *
*Controller:        COntroller to display Scedule line               *
* Defect# :         16472                                            *
* Change FDD/TDD:   FUL_EXT-072_NEW                                  *
* Transport Number: RD2K906449                                       *
* Developer:        Teja Konapalli                                   *
* Creation Date:    APR-11-2023                                      *
*=================================================================== */
sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "sap/m/MessageItem",
    "sap/m/MessagePopover",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/MessageToast",
    "sap/m/Text",
    "sap/m/MessageBox",
    "../model/formatter"
], function (BaseController, JSONModel, History,
    MessageItem, MessagePopover, Dialog, Button, MessageToast, Text, MessageBox, formatter) {
    "use strict";
    var fcSaved, newFc, noFCChg = "X", dataInvalid = "";
    var initData;
    return BaseController.extend("sacquotfc.controller.Object", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

        /**
         * Called when the worklist controller is instantiated.
         * @public
         */
        onInit: function () {
            // Model used to manipulate control states. The chosen values make sure,
            // detail page shows busy indication immediately so there is no break in
            // between the busy indication for loading the view's meta data
            /*    var oViewModel = new JSONModel({
                    busy: true,
                    delay: 0,
                    enable: false
                }); */
            this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
            //  this.setModel(oViewModel, "objectView");

        },
        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */


        /**
         * Event handler  for navigating back.
         * It there is a history entry we go one step back in the browser history
         * If not, it will replace the current entry of the browser history with the worklist route.
         * @public
         */
        onNavBack: function () {
            var sPreviousHash = History.getInstance().getPreviousHash();
            /*    if (sPreviousHash !== undefined) {
                    // eslint-disable-next-line sap-no-history-manipulation
                    history.go(-1);
                } else { 
                    this.getRouter().navTo("worklist", {}, true);
               } */
            if (!this.oConfirmDialog) {
                this.oConfirmDialog = new Dialog({
                    title: "Are you sure to Leave the screen?",
                    content: new Text({ text: "Forcastes are not saved, un saved Data will be Lost" }),
                    type: 'Message',
                    buttons: [
                        new Button({
                            text: "Yes",
                            press: function () {
                                this.oConfirmDialog.close();
                                // oPromise.resolve();
                                if (sPreviousHash !== undefined) {
                                    // eslint-disable-next-line sap-no-history-manipulation
                                    var oPage = this.getView().byId("detailsPage");     //Get Hold of page
                                    //    oPage.scrollTo(0,0);     //Page scroll to top
                                    this.getView().byId("sLTable").rerender();
                                    history.go(-1);
                                } else {
                                    this.getRouter().navTo("worklist", {}, true);
                                }
                                this.oConfirmDialog.close();
                            }.bind(this)
                        }),
                        new Button({
                            text: "No",
                            press: function () {
                                this.oConfirmDialog.close();
                                // oPromise.reject();
                            }.bind(this)
                        })
                    ]
                });
            }
            /**Check if any of the forcast quantities have changed before opening confirmation dialog on back Button**/
            var oTable = this.getView().byId("sLTable");
            var jModel = oTable.getModel("schlModel").getProperty("/results");
            noFCChg = "X"
            for (var i = 0; i < jModel.length; i++) {
                if ((newFc !== "X" && jModel[i].ZfdcQuote !== "" && initData[i].ZfdcQty === jModel[i].ZfdcQty) ||
                    (newFc === "X" && jModel[i].ZfdcQty === "0") ||
                    (newFc !== "X" && jModel[i].ZfdcQuote === "" && jModel[i].ZfduQty1 === "0"
                        && jModel[i].ZfdcQty === "0")) {
                    continue;
                }
                else {
                    noFCChg = "";
                    break;
                }
            }
            if (fcSaved !== "X" && noFCChg === "") {
                this.oConfirmDialog.open();
            } else {
                fcSaved = " ";
                if (sPreviousHash !== undefined) {
                    // eslint-disable-next-line sap-no-history-manipulation
                    var oPage = this.getView().byId("detailsPage"); //Get Hold of page
                    var oTable = this.getView().byId("sLTable");
                    // oTable.setFirstVisibleRow(1)
                    // oPage.scrollTo(0,0);     //Page scroll to top
                    history.go(-1);
                } else {
                    this.getRouter().navTo("worklist", {}, true);
                }
            }
        },

        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

        /**
         * Binds the view to the object path.
         * @function
         * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
         * @private
         */
        _onObjectMatched: function (oEvent) {
            var oHeadModel = new sap.ui.model.json.JSONModel();
            var oHeadDscModel = new sap.ui.model.json.JSONModel();
            var odescModel = sap.ui.getCore().getModel("gDescModel");
            //   var modModel = sap.ui.getCore().getModel("objectView"); 
            var matnr = oEvent.getParameter("arguments").matnr,
                shipTo = oEvent.getParameter("arguments").shipTo, // New Ship To
                soldTo = oEvent.getParameter("arguments").soldTo,
                year = oEvent.getParameter("arguments").year,
                program = oEvent.getParameter("arguments").program,
                entType = oEvent.getParameter("arguments").entType,
                //    frmShipTO = oEvent.getParameter("arguments").cshipTo, // Old Ship To
                //   fromEnttype = oEvent.getParameter("arguments").centType,
                cindex = oEvent.getParameter("arguments").cidx;
            var enableUpdt = true;
            if (cindex !== " ") {
                newFc = "X";
            } else {
                newFc = " "
            }
            //   newFc = oEvent.getParameter("arguments").newFc;
            var oFilters = [];
            oHeadModel.setProperty("/", {
                "matnr": matnr,
                "shipTo": shipTo,
                "soldTo": soldTo,
                "year": year,
                "program": program,
                "entType": entType
            });
            oHeadDscModel.setProperty("/", {
                "matnr": odescModel.oData.MatlDesc + "(" + matnr + ")",
                "shipTo": odescModel.oData.ShipToName + "(" + shipTo + ")",
                "soldTo": odescModel.oData.SoldToName + "(" + soldTo + ")",
                "year": year,
                "program": program,
                "entType": entType,
                "unitPrice": ""
            });
            var oTable = this.getView().byId("sLTable")
            var oModel = new sap.ui.model.json.JSONModel();
            var oDataModel = this.getView().getModel();
            var cQModel = sap.ui.getCore().getModel("gCpyRecMdl");
            var entityset = "/QuotationDetailsSet";
            var qtyu1, qtyu2, qtyc;
            var dataModel = [];
            if (newFc === "X") {
                var oFilterShTo = new sap.ui.model.Filter("CopyShipTo", sap.ui.model.FilterOperator.EQ, shipTo);
                oFilters.push(oFilterShTo);
                oFilterShTo = new sap.ui.model.Filter("ShipTo", sap.ui.model.FilterOperator.EQ, cQModel.oData.ShiptTo);
                oFilters.push(oFilterShTo);

                var oFilterEt = new sap.ui.model.Filter("CopyEntType", sap.ui.model.FilterOperator.EQ, entType);
                oFilters.push(oFilterEt);
                var oFilterEt = new sap.ui.model.Filter("EntType", sap.ui.model.FilterOperator.EQ, cQModel.oData.EntType);
                oFilters.push(oFilterEt);

                var oFilterSlTo = new sap.ui.model.Filter("CopySoldTo", sap.ui.model.FilterOperator.EQ, soldTo);
                oFilters.push(oFilterSlTo);
                var oFilterSlTo = new sap.ui.model.Filter("SoldTo", sap.ui.model.FilterOperator.EQ, cQModel.oData.SoldTo);
                oFilters.push(oFilterSlTo);

                var oFilterMt = new sap.ui.model.Filter("CopyMaterial", sap.ui.model.FilterOperator.EQ, matnr);
                oFilters.push(oFilterMt);
                oFilterMt = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, cQModel.oData.Material);
                oFilters.push(oFilterMt);

                var oFilterPg = new sap.ui.model.Filter("CopyProgram", sap.ui.model.FilterOperator.EQ, program);
                oFilters.push(oFilterPg);
                oFilterPg = new sap.ui.model.Filter("Program", sap.ui.model.FilterOperator.EQ, cQModel.oData.Program);
                oFilters.push(oFilterPg);

            } else {
                oFilterShTo = new sap.ui.model.Filter("ShipTo", sap.ui.model.FilterOperator.EQ, shipTo);
                oFilters.push(oFilterShTo);
                oFilterEt = new sap.ui.model.Filter("EntType", sap.ui.model.FilterOperator.EQ, entType);
                oFilters.push(oFilterEt);
                var oFilterMt = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, matnr);
                oFilters.push(oFilterMt);
                var oFilterSlTo = new sap.ui.model.Filter("SoldTo", sap.ui.model.FilterOperator.EQ, soldTo);
                oFilters.push(oFilterSlTo);
                oFilterPg = new sap.ui.model.Filter("Program", sap.ui.model.FilterOperator.EQ, program);
                oFilters.push(oFilterPg);

            }
            if (year) {
                var oFilterYr = new sap.ui.model.Filter("Year", sap.ui.model.FilterOperator.EQ, year);
                oFilters.push(oFilterYr);
            };
            oTable.setBusy(true);
            oDataModel.read(entityset, {
                filters: oFilters,
                success: function (oData, response) {
                    //Save different data into seperate Model for later comparision
                    var hdrMessage = response.headers["sap-message"]
                    if (hdrMessage) {
                        var hdrMessageObject = JSON.parse(hdrMessage);
                        fcSaved = "X";
                        enableUpdt = false;
                        sap.m.MessageBox.show(
                            hdrMessageObject.message,
                            sap.m.MessageBox.Icon.ERROR,
                            "Data Error"
                        );
                        this.screenMod(enableUpdt);
                        var data = oData.results
                        data.forEach(function (item) {
                            item.IsEditable = false;
                            qtyc = item.ZfdcQty.split('.');
                            item.ZfdcQty = qtyc[0];
                            qtyu1 = item.ZfduQty1.split('.');
                            item.ZfduQty1 = qtyu1[0];
                            qtyu2 = item.ZfduQty2.split('.');
                            item.ZfduQty2 = qtyu2[0];
                            //,qtyu2,qtyc;
                        })
                    } else {
                        var data = oData.results
                        data.forEach(function (item) {
                            if (item.IsEditable === 'true') {
                                item.IsEditable = true;
                            } else {
                                item.IsEditable = false;
                            }
                            qtyc = item.ZfdcQty.split('.');
                            item.ZfdcQty = qtyc[0];
                            qtyu1 = item.ZfduQty1.split('.');
                            item.ZfduQty1 = qtyu1[0];
                            qtyu2 = item.ZfduQty2.split('.');
                            item.ZfduQty2 = qtyu2[0];
                        })
                        enableUpdt = true;
                        this.screenMod(enableUpdt);
                        oHeadDscModel.oData.unitPrice = data[0].BaseUnitPrice + " / " + data[0].BaseQty + " " + data[0].BaseUom;
                    }
                    oHeadDscModel.refresh();
                    oTable.setBusy(false);
                    oModel.setData(oData);
                    oTable.setModel(oModel, "schlModel");
                    initData = JSON.parse(JSON.stringify(oData.results));
                }.bind(this),
                error: function (error) {
                    oTable.setBusy(false);
                }
            });
            this.setModel(oHeadDscModel, "transfDescModel");
            this.setModel(oHeadModel, "transfModel");
        },
        screenMod: function (enableUpdt) {
            var oViewModel = new JSONModel({
                enable: enableUpdt
            });
            this.setModel(oViewModel, "objectView");
        },
        /* =========================================================== */
        /* Utility Methods                                             */
        /* =========================================================== */
        onQZero: function () {
            if (!this.oConfirmZeroDialog) {
                this.oConfirmZeroDialog = new Dialog({
                    title: "Set to Zero Quantity?",
                    content: new Text({ text: "Are you sure to Zero down all Quantities?" }),
                    type: 'Message',
                    buttons: [
                        new Button({
                            text: "Yes",
                            press: function () {
                                this.oConfirmZeroDialog.close();
                                // oPromise.resolve();
                                var oTable = this.getView().byId("sLTable");
                                var oModel = oTable.getModel("schlModel");
                                var oData = oModel.getData();
                                // var prop = oTable.getProperty('SO_quot_itmSet');
                                for (var i = 0; i < oData.results.length; i++) {
                                    if (oData.results[i].IsEditable === true) {
                                        oData.results[i].ZfdcQty = "0";
                                    }
                                }
                                oModel.refresh();
                                this.oConfirmZeroDialog.close();
                            }.bind(this)
                        }),
                        new Button({
                            text: "No",
                            press: function () {
                                this.oConfirmZeroDialog.close();
                                // oPromise.reject();
                            }.bind(this)
                        })
                    ]
                });
            }
            this.oConfirmZeroDialog.open();
        },
        onreset: function () {
            if (!this.oConfirmResetDialog) {
                this.oConfirmResetDialog = new Dialog({
                    title: "Reset Quantities ?",
                    content: new Text({ text: "Are you sure to Reset Quantities to actuals?" }),
                    type: 'Message',
                    buttons: [
                        new Button({
                            text: "Yes",
                            press: function () {
                                this.oConfirmResetDialog.close();
                                var oTable = this.getView().byId("sLTable");
                                var oModel = oTable.getModel("schlModel");
                                var oData = oModel.getData();
                                for (var i = 0; i < oData.results.length; i++) {
                                    oData.results[i].ZfdcQty = initData[i].ZfdcQty;
                                }
                                oModel.refresh();
                                this.oConfirmResetDialog.close();
                            }.bind(this)
                        }),
                        new Button({
                            text: "No",
                            press: function () {
                                this.oConfirmResetDialog.close();
                            }.bind(this)
                        })
                    ]
                });
            }
            this.oConfirmResetDialog.open();
        },
        /* =========================================================== */
        /* Data Updation methods                                       */
        /* =========================================================== */
        onQUpdate: function () {
            var oTable = this.getView().byId("sLTable");
            var jModel = oTable.getModel("schlModel").getProperty("/results");
            const digits_only = string => [...string].every(c => '0123456789'.includes(c));
            for (var i = 0; i < jModel.length; i++) {
                if (digits_only(jModel[i].ZfdcQty) === false) {
                    sap.m.MessageBox.show(
                        "Please correct quantity errors before updating Forecasts",
                        sap.m.MessageBox.Icon.ERROR,
                        "Input Error"
                    );
                    return;
                }
            };
            if (!this.oConfirmQUpdateDialog) {
                this.oConfirmQUpdateDialog = new Dialog({
                    title: "Update Forecasts ?",
                    content: new Text({ text: "Are you sure to Update Forecasts?" }),
                    type: 'Message',
                    buttons: [
                        new Button({
                            text: "Yes",
                            press: function () {
                                this.oConfirmQUpdateDialog.close();
                                var oTabModel = oTable.getModel("schlModel");
                                var oData = oTabModel.getData();
                                var oModel = this.getView().getModel();
                                oModel.setUseBatch(true);
                                // var model = sap.ui.getCore().getModel("gquotesModel");
                                var descModel = sap.ui.getCore().getModel("gDescModel");
                                //  var sldModel = sap.ui.getCore().getModel("gSldToModel").getProperty("/results");
                                   var jModel = oTable.getModel("schlModel").getProperty("/results");
                                var model = sap.ui.getCore().getModel("gquotesModel");
                                var year = this.getView().byId("v2Year").getText();
                                var oHeadModel = this.getModel("transfModel");
                                if (newFc === "X") {
                                    var soldToName, ShipToName, MatlDesc;
                                    var soldToName = descModel.oData.SoldToName;
                                    var ShipToName = descModel.oData.ShipToName;
                                    var MatlDesc = descModel.oData.MatlDesc;
                                }
                                var _oProperties = {
                                    Material: oHeadModel.oData.matnr,
                                    SoldTo: oHeadModel.oData.soldTo,
                                    ShipTo: oHeadModel.oData.shipTo,
                                    Program: oHeadModel.oData.program,
                                    Year: year,
                                    EntType: oHeadModel.oData.entType,
                                    SoldToName: soldToName,
                                    ShipToName: ShipToName,
                                    MatlDesc: MatlDesc
                                };
                                if (jQuery.sap.equal(oData.results, initData) === "true") {
                                    MessageToast.show("Data not changed");
                                };
                                noFCChg = "X";
                                for (var i = 0; i < jModel.length; i++) {
                                    if ((jModel[i].IsEditable === false) || (newFc !== "X" && jModel[i].ZfdcQuote !== "" && initData[i].ZfdcQty === jModel[i].ZfdcQty) ||
                                        (newFc === "X" && jModel[i].ZfdcQty === "0") ||
                                        (newFc !== "X" && jModel[i].ZfdcQuote === "" && jModel[i].ZfduQty1 === "0"
                                            && jModel[i].ZfdcQty === "0")) {
                                        continue;
                                    }
                                    var oEntry = jModel[i];
                                    noFCChg = "";
                                    if (newFc === "X") {
                                        oEntry.CopyShipTo = oEntry.ShipTo; //Copy old Ship to copy SHip TO
                                        oEntry.CopyMaterial = oEntry.Material;//Copy old Material to copy Material
                                        oEntry.CopyEntType = oEntry.EntType;//Copy old EntType to copy EntType
                                        oEntry.CopyProgram = oEntry.Program;//Copy old Program to copy Program
                                        oEntry.CopySoldTo = oEntry.SoldTo;//Copy old SoldTo to copy SoldTo
                                        oEntry.ShipTo = oHeadModel.oData.shipTo; //Copy New SHip To to SHip To
                                        oEntry.EntType = oHeadModel.oData.entType; // New ShipTo
                                        oEntry.Material = oHeadModel.oData.matnr;//New Material
                                        oEntry.Program = oHeadModel.oData.program;//New Program
                                        oEntry.SoldTo = oHeadModel.oData.soldTo;//New SOld To
                                    }
                                    if (oEntry.IsEditable === true) {
                                        oEntry.IsEditable = 'true'
                                    } else {
                                        oEntry.IsEditable = 'false'
                                    }
                                    oModel.create("/QuotationDetailsSet", oEntry, {
                                        method: "POST",
                                        success: function (data) {
                                            fcSaved = "X"
                                        },
                                        error: function (e) {
                                            var msg = 'Post Failure';
                                        }
                                    });
                                }
                                if (noFCChg === "") {
                                    oModel.submitChanges({
                                        success: function (data, response) {
                                            if (newFc === "X") {
                                                fcSaved = "X";
                                                var data = model.getData();
                                                data.results.push(_oProperties);
                                                model.refresh();
                                            }
                                            var msg = 'Forecasts are in Processing of Saving';
                                            MessageToast.show(msg);
                                            history.go(-1);

                                            //  var msg = 'Post submitChanges Success';
                                            //   MessageToast.show(msg);
                                        }.bind(this),
                                        error: function (e) {
                                            var msg = 'Post submitChanges Failure';
                                            MessageToast.show(msg);
                                        }
                                    });
                                } else {
                                    MessageBox.information("No Changes Made to any forecasts");
                                }
                            }.bind(this)
                        }), new Button({
                            text: "No",
                            press: function () {
                                this.oConfirmQUpdateDialog.close();
                            }.bind(this)
                        })
                    ]
                });
            }
            this.oConfirmQUpdateDialog.open();
        },
        /* =========================================================== */
        /* Data Validation methods                                     */
        /* =========================================================== */
        setDecimals: function (oEvent) {
            var Qty = oEvent.getParameters().value;
            if (Qty === "") {
                Qty = "0"
            }
            //   Qty = parseFloat(Qty).toFixed(3);
            oEvent.getSource().setValue(Qty);
        },
        onQtyChange: function (oEvent) {
            //this.value = parseFloat(this.value).toFixed(3);
            var Qty = oEvent.getParameters().value;
            var cellId = oEvent.getSource().getId()
            if (Qty < 0) {
                sap.ui.getCore().byId(cellId).setValueState(sap.ui.core.ValueState.Error);
                sap.ui.getCore().byId(cellId).setValueStateText("Invalid Quantity");
                dataInvalid = "X";
            } else {
                sap.ui.getCore().byId(cellId).setValueState(sap.ui.core.ValueState.None);
                dataInvalid = "";
            }
            const digits_only = string => [...string].every(c => '0123456789'.includes(c));
            if (digits_only(Qty) === false) {
                sap.ui.getCore().byId(cellId).setValueState(sap.ui.core.ValueState.Error);
                sap.ui.getCore().byId(cellId).setValueStateText("Invalid Quantity");
            } else {
                sap.ui.getCore().byId(cellId).setValueState(sap.ui.core.ValueState.None);
                sap.ui.getCore().byId(cellId).setValueStateText("");
            }
        },
        onMessagesButtonPress: function (oEvent) {

            var oMessagesButton = oEvent.getSource();
            if (!this._messagePopover) {
                this._messagePopover = new MessagePopover({
                    items: {
                        path: "message>/",
                        template: new MessageItem({
                            description: "{message>description}",
                            type: "{message>type}",
                            title: "{message>message}"
                        })
                    }
                });
                oMessagesButton.addDependent(this._messagePopover);
            }
            this._messagePopover.toggle(oMessagesButton);
        },
        /**
         * Binds the view to the object path.
         * @function
         * @param {string} sObjectPath path to the object to be bound
         * @private
         */
        _bindView: function (sObjectPath) {
            var oViewModel = this.getModel("objectView");

            this.getView().bindElement({
                path: sObjectPath,
                events: {
                    change: this._onBindingChange.bind(this),
                    dataRequested: function () {
                        oViewModel.setProperty("/busy", true);
                    },
                    dataReceived: function () {
                        oViewModel.setProperty("/busy", false);
                    }
                }
            });
        },

        _onBindingChange: function () {
            var oView = this.getView(),
                oViewModel = this.getModel("objectView"),
                oElementBinding = oView.getElementBinding();

            // No data for the binding
            if (!oElementBinding.getBoundContext()) {
                this.getRouter().getTargets().display("objectNotFound");
                return;
            }

            var oResourceBundle = this.getResourceBundle(),
                oObject = oView.getBindingContext().getObject(),
                sObjectId = oObject.Program,
                sObjectName = oObject.QuotationsSet;

            oViewModel.setProperty("/busy", false);
            oViewModel.setProperty("/shareSendEmailSubject",
                oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
            oViewModel.setProperty("/shareSendEmailMessage",
                oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
        }
    });

});
